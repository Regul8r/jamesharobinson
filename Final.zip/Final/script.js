function changeColor(el) 
{
    document.body.style.backgroundColor = el.value;
    var colorSelected = document. querySelector ("#theColors").value;   
    console.log(userInput + " has chosen " + colorSelected);
    
  }